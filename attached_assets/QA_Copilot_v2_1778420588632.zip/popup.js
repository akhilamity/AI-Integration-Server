"use strict";(()=>{var q="https://api.openai.com/v1/chat/completions",j="https://31f52759-a9bf-4e97-aaa4-b72cb30d3953-00-x452ickeis9e.sisko.replit.dev",i=[],d=null,u=!1,H="log",O="ALL",T=null,r=null,L=null,S=!1,y="",b="",m="server",o=e=>document.querySelector(e),f=e=>e?.classList.remove("hidden"),E=e=>e?.classList.add("hidden");function I(e){let t=Math.floor(e/1e3),n=Math.floor(t/60),s=Math.floor(n/60);return s>0?`${s}:${String(n%60).padStart(2,"0")}:${String(t%60).padStart(2,"0")}`:`${n}:${String(t%60).padStart(2,"0")}`}function M(e,t){return"+"+I(e-t)}function G(e){return{CLICK:"Click",INPUT:"Input",PAGE_LOAD:"Page",PAGE_UNLOAD:"Leave",API_CALL:"API",API_ERROR:"Err",CONSOLE_ERROR:"JSErr",CONSOLE_WARN:"Warn",STORAGE_CHANGE:"Store",SCREENSHOT:"Shot"}[e]??e}function N(e){let t=e.payload;switch(e.type){case"CLICK":return t.text?.trim()||t.selector||t.tag;case"INPUT":return`${t.field||"field"}: ${t.value}`;case"PAGE_LOAD":case"PAGE_UNLOAD":return t.title||t.url;case"API_CALL":return`${t.method} ${t.url.replace(/https?:\/\/[^/]+/,"")}`;case"API_ERROR":return`${t.method} ${t.url.replace(/https?:\/\/[^/]+/,"")} failed`;case"CONSOLE_ERROR":return t.error?.slice(0,80)??"Error";case"CONSOLE_WARN":return t.message?.slice(0,80)??"Warning";case"STORAGE_CHANGE":return`${t.key}: ${t.value}`;default:return JSON.stringify(t).slice(0,60)}}function x(e){let t=e.payload;switch(e.type){case"CLICK":case"INPUT":return t.page;case"PAGE_LOAD":case"PAGE_UNLOAD":return t.url;case"API_CALL":return`${t.status} \xB7 ${t.duration}ms \xB7 ${t.page}`;case"API_ERROR":return t.error?.slice(0,80)??"";case"CONSOLE_ERROR":case"CONSOLE_WARN":return t.page;default:return""}}function v(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function P(){let e=o("#action-list"),t=O==="ALL"?i:i.filter(s=>s.type===O);if(t.length===0){e.innerHTML=`<div class="empty">
      <div class="empty-icon">\u{1F4CB}</div>
      <div class="empty-title">${i.length===0?"No actions recorded":"No matching actions"}</div>
      <div class="empty-desc">${i.length===0?"Start recording to capture browser activity":"Try a different filter"}</div>
    </div>`;return}let n=d??t[0].timestamp;e.innerHTML=t.slice().reverse().map(s=>`
    <div class="action-item">
      <span class="action-badge badge-${s.type.toLowerCase()}">${G(s.type)}</span>
      <div class="action-body">
        <div class="action-main">${v(N(s))}</div>
        ${x(s)?`<div class="action-sub">${v(x(s))}</div>`:""}
      </div>
      <div class="action-time">${M(s.timestamp,n)}</div>
    </div>`).join("")}function C(){let e={};for(let t of i)e[t.type]=(e[t.type]??0)+1;return e}function J(){let e=o("#stats-content");if(i.length===0){e.innerHTML='<div class="empty"><div class="empty-icon">\u{1F4CA}</div><div class="empty-title">No data yet</div><div class="empty-desc">Record a session to see stats</div></div>';return}let t=C(),n=(t.CONSOLE_ERROR??0)+(t.API_ERROR??0),s=t.API_CALL??0,l=new Set(i.filter(g=>g.type==="PAGE_LOAD").map(g=>g.payload.url)),a=[["CLICK","#3b82f6"],["INPUT","#22c55e"],["PAGE_LOAD","#a855f7"],["API_CALL","#38bdf8"],["API_ERROR","#ef4444"],["CONSOLE_ERROR","#f87171"],["CONSOLE_WARN","#f59e0b"]],c=Math.max(...Object.values(t),1),p=a.filter(([g])=>t[g]).map(([g,z])=>`
    <div class="breakdown-row">
      <span class="breakdown-label">${g}</span>
      <div class="breakdown-bar-wrap">
        <div class="breakdown-bar" style="width:${t[g]/c*100}%;background:${z}"></div>
      </div>
      <span class="breakdown-count">${t[g]}</span>
    </div>`).join(""),U=[...l].slice(0,6).map(g=>`
    <div class="page-item">
      <span class="page-url">${v(g)}</span>
    </div>`).join("");e.innerHTML=`
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-value">${i.length}</div>
        <div class="stat-label">Total Actions</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${n>0?`<span style="color:var(--red)">${n}</span>`:"0"}</div>
        <div class="stat-label">Errors</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${l.size}</div>
        <div class="stat-label">Pages Visited</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${s}</div>
        <div class="stat-label">API Calls</div>
      </div>
      <div class="stat-card wide">
        <div class="stat-label" style="margin-bottom:6px">Event Breakdown</div>
        <div class="breakdown">${p}</div>
      </div>
    </div>
    ${l.size>0?`<div class="pages-list"><div class="pages-title">Pages Visited</div>${U}</div>`:""}
  `}function R(){let e=o("#report-content");if(S){e.innerHTML=`<div class="report-loading">
      <div class="spinner"></div>
      <div class="report-loading-text">Analyzing your session with AI...</div>
    </div>`;return}if(L){let a=L.includes("No API key");e.innerHTML=`<div class="report-error">
      \u26A0\uFE0F ${v(L)}
      ${a?'<br><br><button class="btn btn-secondary" id="go-settings-btn" style="margin:0 auto;display:block">\u2699 Open Settings</button>':""}
    </div>`,a&&document.getElementById("go-settings-btn")?.addEventListener("click",()=>w("settings"));return}if(!r){let a=i.length>0,c=m==="server"?!!b:!!y,p=m==="server"?"Add your server URL in \u2699 Settings to enable AI analysis":"Add your OpenAI API key in \u2699 Settings to enable AI analysis";e.innerHTML=`<div class="report-prompt">
      <div class="report-icon">\u{1F916}</div>
      <div class="report-prompt-title">AI QA Analysis</div>
      <div class="report-prompt-desc">${c?a?`${i.length} actions ready to analyze`:"Record a session first, then analyze it":p}</div>
      ${c?a?'<button class="btn btn-analyze" id="analyze-btn-inline" style="width:100%;max-width:200px">\u2728 Analyze Session</button>':"":'<button class="btn btn-secondary" id="go-settings-btn2" style="margin-top:4px">\u2699 Open Settings</button>'}
    </div>`,document.getElementById("analyze-btn-inline")?.addEventListener("click",k),document.getElementById("go-settings-btn2")?.addEventListener("click",()=>w("settings"));return}let t={high:"severity-high",medium:"severity-medium",low:"severity-low",info:"severity-info"},n=r.bugs.length===0?'<div style="color:var(--green)">\u2713 No bugs detected</div>':r.bugs.map(a=>`
          <div style="margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid var(--border)">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
              <span class="severity-badge ${t[a.severity?.toLowerCase()]??"severity-info"}">${v(a.severity?.toUpperCase()??"INFO")}</span>
              <strong style="color:var(--text);font-size:12px">${v(a.title)}</strong>
            </div>
            <div style="font-size:11px">${v(a.detail)}</div>
          </div>`).join(""),s=r.testSteps.map((a,c)=>`<li>${c+1}. ${v(a)}</li>`).join(""),l=r.recommendations.map(a=>`<li>${v(a)}</li>`).join("");e.innerHTML=`<div class="report-content" style="padding:12px 16px;display:flex;flex-direction:column;gap:10px">
    <div class="report-section">
      <div class="report-section-header">\u{1F4CB} Summary</div>
      <div class="report-section-body">${v(r.summary)}</div>
    </div>
    <div class="report-section">
      <div class="report-section-header">\u{1F41B} Bugs & Issues (${r.bugs.length})</div>
      <div class="report-section-body">${n}</div>
    </div>
    <div class="report-section">
      <div class="report-section-header">\u{1F5C2}\uFE0F Test Steps</div>
      <div class="report-section-body"><ul>${s}</ul></div>
    </div>
    <div class="report-section">
      <div class="report-section-header">\u{1F4A1} Recommendations</div>
      <div class="report-section-body"><ul>${l}</ul></div>
    </div>
    <div class="report-section">
      <div class="report-section-header">\u{1F3AF} Coverage</div>
      <div class="report-section-body">${v(r.coverage)}</div>
    </div>
    <button class="btn btn-analyze" id="reanalyze-btn" style="width:100%">\u21BB Re-analyze</button>
  </div>`,document.getElementById("reanalyze-btn")?.addEventListener("click",()=>{r=null,k()})}function h(){let e=o("#settings-content"),t=m==="server";e.innerHTML=`
    <div class="settings-body">

      <div class="settings-section">
        <div class="settings-label">AI Mode</div>
        <div class="settings-mode-row">
          <button class="mode-btn ${t?"active":""}" id="mode-server">\u{1F5A5} Server (free)</button>
          <button class="mode-btn ${t?"":"active"}" id="mode-openai">\u{1F511} My OpenAI Key</button>
        </div>
      </div>

      ${t?`
      <div class="settings-section" id="server-section">
        <div class="settings-label">Server URL</div>
        <div class="settings-desc">The URL of your deployed QA Copilot API server. AI analysis runs on the server \u2014 no key needed.</div>
        <div class="settings-row">
          <input
            type="url"
            id="server-url-input"
            class="settings-input"
            placeholder="https://your-app.replit.app"
            value="${v(b)}"
            autocomplete="off"
            spellcheck="false"
          />
          <button class="btn-save" id="save-server-btn">Save</button>
        </div>
        ${b?'<div class="settings-status ok">\u2713 Server configured</div>':'<div class="settings-status">No server URL set</div>'}
      </div>
      `:`
      <div class="settings-section" id="openai-section">
        <div class="settings-label">OpenAI API Key</div>
        <div class="settings-desc">Stored locally, sent only to OpenAI. Get one at <strong>platform.openai.com/api-keys</strong>. Uses gpt-4o-mini (~$0.001 per analysis).</div>
        <div class="settings-row">
          <input
            type="password"
            id="api-key-input"
            class="settings-input"
            placeholder="sk-..."
            value="${v(y)}"
            autocomplete="off"
            spellcheck="false"
          />
          <button class="btn-save" id="save-key-btn">Save</button>
        </div>
        ${y?'<div class="settings-status ok">\u2713 API key saved</div>':'<div class="settings-status">No key set \u2014 add one to enable AI analysis</div>'}
      </div>
      `}

      <div class="settings-section">
        <div class="settings-label">Privacy</div>
        <div class="settings-desc">Password fields are always redacted before recording. Session data is only sent when you click Analyze.</div>
      </div>

    </div>
  `,document.getElementById("mode-server")?.addEventListener("click",async()=>{m="server",await chrome.storage.local.set({qa_ai_mode:"server"}),h(),A()}),document.getElementById("mode-openai")?.addEventListener("click",async()=>{m="openai",await chrome.storage.local.set({qa_ai_mode:"openai"}),h(),A()}),document.getElementById("save-server-btn")?.addEventListener("click",async()=>{b=o("#server-url-input").value.trim().replace(/\/$/,""),await chrome.storage.local.set({qa_server_url:b}),h(),A(),_()}),document.getElementById("save-key-btn")?.addEventListener("click",async()=>{y=o("#api-key-input").value.trim(),await chrome.storage.local.set({qa_api_key:y}),h(),A(),_()})}async function k(){if(i.length===0)return;if(!(m==="server"?!!b:!!y)){L=m==="server"?"No server URL configured. Add one in \u2699 Settings.":"No OpenAI API key configured. Add one in \u2699 Settings.",S=!1,R();return}S=!0,L=null,r=null,R();try{m==="server"?await K():await V()}catch(t){L=String(t)}finally{S=!1,R()}}async function K(){let e=await fetch(`${b}/api/analyze`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({actions:i,sessionStart:d})});if(!e.ok){let t=await e.text().catch(()=>"");throw new Error(`Server error ${e.status}: ${t.slice(0,200)}`)}r=await e.json()}async function V(){let e=d??i[0].timestamp,n=`You are a QA engineer reviewing a browser session recording. Analyze the following session log and return a JSON object.

SESSION LOG:
${i.map(p=>`[${M(p.timestamp,e)}] ${p.type}: ${JSON.stringify(p.payload).slice(0,200)}`).join(`
`)}

Return ONLY valid JSON (no markdown, no code fences) with this exact shape:
{
  "summary": "2-3 sentence overview of what was tested and overall quality",
  "bugs": [
    { "title": "short bug title", "severity": "high|medium|low|info", "detail": "1-2 sentence description" }
  ],
  "testSteps": ["step 1", "step 2"],
  "recommendations": ["rec 1", "rec 2"],
  "coverage": "1-2 sentences on what was covered and what gaps exist"
}

Focus on: console errors, API errors (4xx/5xx), broken flows, slow API calls (>2s), missing validations.`,s=await fetch(q,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${y}`},body:JSON.stringify({model:"gpt-4o-mini",max_tokens:2048,messages:[{role:"user",content:n}]})});if(!s.ok){let p=await s.text();throw s.status===401?new Error("Invalid API key. Check your key in \u2699 Settings."):s.status===429?new Error("OpenAI quota exceeded. Check billing at platform.openai.com, or switch to Server mode in \u2699 Settings."):new Error(`OpenAI error ${s.status}: ${p.slice(0,200)}`)}let c=((await s.json()).choices[0]?.message?.content??"").match(/\{[\s\S]*\}/);if(!c)throw new Error("Could not parse AI response as JSON.");r=JSON.parse(c[0])}function B(){let e=o(".status-dot"),t=o(".status-text"),n=o(".status-time");if(e.className="status-dot "+(u?"recording":i.length>0?"stopped":""),t.innerHTML=u?"<strong>Recording</strong> \u2014 capturing browser activity":i.length>0?`<strong>Stopped</strong> \u2014 ${i.length} actions captured`:"Ready to record",u&&d)n.textContent=I(Date.now()-d);else if(!u&&d&&i.length>0){let s=(i[i.length-1]?.timestamp??d)-d;n.textContent=I(s)}else n.textContent=""}function A(){let e=o("#start-btn"),t=o("#stop-btn"),n=o("#analyze-btn"),s=o("#clear-btn"),l=o("#export-json"),a=o("#export-md");e.disabled=u,t.disabled=!u;let c=m==="server"?!!b:!!y;n.disabled=u||i.length===0||!c,s.disabled=u||i.length===0,l&&(l.disabled=i.length===0),a&&(a.disabled=i.length===0)}function D(){let e=C();document.querySelectorAll(".filter-chip").forEach(t=>{let n=t.dataset.type??"ALL",s=n==="ALL"?i.length:e[n]??0,l=t.querySelector(".filter-chip-count");l&&(l.textContent=String(s)),t.classList.toggle("active",O===n),t.disabled=n!=="ALL"&&s===0})}function _(){let e=o("#tab-log-badge"),t=o("#tab-report-badge"),n=C(),s=(n.CONSOLE_ERROR??0)+(n.API_ERROR??0);e.textContent=String(i.length),s>0?(t.textContent=String(s),t.style.background="var(--red)",t.style.color="#fff"):r?(t.textContent="\u2713",t.style.background="var(--green)",t.style.color="#000"):(t.textContent="",t.style.background="",t.style.color="")}function w(e){H=e,document.querySelectorAll(".tab").forEach(p=>{p.classList.toggle("active",p.dataset.tab===e)});let t=o("#log-view"),n=o("#stats-view"),s=o("#report-view"),l=o("#settings-view"),a=o("#filter-bar"),c=o("#export-bar");E(t),E(n),E(s),E(l),E(a),e==="log"?(f(t),f(a),f(c),P()):e==="stats"?(f(n),f(c),J()):e==="report"?(f(s),f(c),R()):(f(l),E(c),h())}function $(){B(),A(),D(),_(),w(H)}function W(){let e={sessionStart:d?new Date(d).toISOString():null,exportedAt:new Date().toISOString(),actionCount:i.length,actions:i},t=new Blob([JSON.stringify(e,null,2)],{type:"application/json"}),n=URL.createObjectURL(t),s=document.createElement("a");s.href=n,s.download=`qa-session-${Date.now()}.json`,s.click(),URL.revokeObjectURL(n)}function F(){let e=["# QA Session Report","",`**Date:** ${d?new Date(d).toLocaleString():"Unknown"}`,`**Actions:** ${i.length}`,""];if(r){if(e.push("## Summary",r.summary,""),e.push("## Bugs & Issues"),r.bugs.length===0)e.push("No bugs detected.");else for(let a of r.bugs)e.push(`- **[${a.severity.toUpperCase()}]** ${a.title}: ${a.detail}`);e.push("","## Test Steps",...r.testSteps.map((a,c)=>`${c+1}. ${a}`),"","## Recommendations",...r.recommendations.map(a=>`- ${a}`),"","## Coverage Notes",r.coverage,"")}e.push("## Session Log");let t=d??i[0]?.timestamp??Date.now();for(let a of i)e.push(`- \`${M(a.timestamp,t)}\` **${a.type}**: ${N(a)}`);let n=new Blob([e.join(`
`)],{type:"text/markdown"}),s=URL.createObjectURL(n),l=document.createElement("a");l.href=s,l.download=`qa-report-${Date.now()}.md`,l.click(),URL.revokeObjectURL(s)}async function Q(){let e=await chrome.storage.local.get(["isRecording","qa_session_actions","qa_session_start","qa_api_key","qa_server_url","qa_ai_mode"]);u=e.isRecording??!1,i=e.qa_session_actions??[],d=e.qa_session_start??null,y=e.qa_api_key??"",b=e.qa_server_url??j,m=e.qa_ai_mode??"server",$()}function Y(){T&&clearInterval(T),T=setInterval(()=>{u&&B()},1e3)}document.addEventListener("DOMContentLoaded",async()=>{await Q(),Y(),o("#start-btn").addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"START_RECORDING"}),u=!0,i=[],d=Date.now(),r=null,L=null,$()}),o("#stop-btn").addEventListener("click",async()=>{let e=await chrome.runtime.sendMessage({type:"STOP_RECORDING"});u=!1,i=e.actions??i,d=e.sessionStart??d,$()}),o("#analyze-btn").addEventListener("click",()=>{w("report"),!r&&!S&&k()}),o("#clear-btn").addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"CLEAR_SESSION"}),i=[],d=null,r=null,L=null,$()}),document.querySelectorAll(".tab").forEach(e=>{e.addEventListener("click",()=>{w(e.dataset.tab)})}),document.querySelectorAll(".filter-chip").forEach(e=>{e.addEventListener("click",()=>{O=e.dataset.type??"ALL",D(),P()})}),o("#export-json").addEventListener("click",W),o("#export-md").addEventListener("click",F)});})();
